package lab12;

import java.util.ArrayList;
import java.util.List;

public class Database {
    List<User> users = new ArrayList<>();
    List<Product> products = new ArrayList<>();
    List<Purchase> purchases = new ArrayList<>();
    Database(){
        users.add(new User("user1", "123456"));
        users.add(new User("user2", "123456"));
        users.add(new User("user3", "123456"));
        products.add(new Product("MacbookPro1", "13Inch 2.0GHz quad-core 10th-generation Intel Core i5 processor, Turbo Boost up to 3.8GHz", 1000));
        products.add(new Product("MacbookPro2", "15Inch 2.0GHz quad-core 10th-generation Intel Core i5 processor, Turbo Boost up to 3.8GHz", 1200));
        products.add(new Product("MacbookPro3", "17Inch 2.0GHz quad-core 10th-generation Intel Core i5 processor, Turbo Boost up to 3.8GHz", 1500));
        products.add(new Product("MacbookPro4", "19Inch 2.0GHz quad-core 10th-generation Intel Core i5 processor, Turbo Boost up to 3.8GHz", 2000));
        products.add(new Product("MacbookPro5", "24Inch 2.0GHz quad-core 10th-generation Intel Core i5 processor, Turbo Boost up to 3.8GHz", 2500));
        products.add(new Product("MacbookPro6", "32Inch 2.0GHz quad-core 10th-generation Intel Core i5 processor, Turbo Boost up to 3.8GHz", 3000));
    }
    boolean findUser(User user){
        return users.contains(user);
    }
    boolean findPurchase(Purchase purchase){
        return purchases.contains(purchase);
    }
    void addPurchase(Purchase purchase){
        purchases.add(purchase);
    }
    boolean findProduct(Product product){
        return products.contains(product);
    }
    List<Product> getProducts()
    {
        return products;
    }
    List<User> getUsers()
    {
        return users;
    }
}
