package lab12;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Optional;

@WebServlet("/login")
public class Login extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter writer = resp.getWriter();

        String rememberMe = "";

        //search "remember_me" cookie
        if(req.getCookies()!=null) {
            Optional<String> s = Arrays.stream(req.getCookies())
                    .filter(c -> "remember-me".equals(c.getName()))
                    .map(Cookie::getValue)
                    .findAny();
            if (s.isPresent()) {
                rememberMe = s.get();
            }
        }
        String rememberMeCheck = (!rememberMe.equals(""))?" checked":"";
        writer.print("<html>");
        writer.write("<title></title>");
        writer.write("<body>");
        writer.write("<div style=\"width:50%;text-align:center;margin-left:auto;margin-right:auto\">");
        writer.write("<form action=\"\" method=\"post\">");
        writer.write("<p> Username: <input type=\"text\" name=\"username\"" + "value=\"" + rememberMe + "\"></p>");
        writer.write("<p> Password: <input type=\"password\" name=\"password\"></p>");
        writer.write("<input type=\"checkbox\" name=\"remember-me\" id=\"rem\" " + rememberMeCheck + ">");
        writer.write("<label for=\"rem\">Remember me</label>");
        writer.write("<p><input type=\"submit\" value=\"login\"></p></form");
        String loginFail = (String)req.getSession().getAttribute("msg-login-fail");
        if(loginFail!=null) {
            writer.write("<p> <h4  style=\"color:red;\"> " + loginFail + "</h4></p>");
            req.getServletContext().removeAttribute("msg-login-fail");
        }
        writer.write("<br> <br> <br>");
        writer.write("<p> <h4>Use the follow data for testing </h4></p>");
        writer.write("<p> user1/123456</h2></p>");
        writer.write("<p> user2/123456</h2></p>");
        writer.write("<p> user3/123456</h2></p>");
        writer.write("</form");
        writer.write("</div");
        writer.write("</body>");
        writer.write("</html>");
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        PrintWriter writer = resp.getWriter();
        String name = req.getParameter("username");
        String pass = req.getParameter("password");
        String rememberMe = req.getParameter("remember-me");
        User user = new User(name, pass);

        //init DB
        Database db = (Database) req.getServletContext().getAttribute("database");
        if(db == null)
        {
            //create one
            db = new Database();
            req.getServletContext().setAttribute("database", db);
        }
       if(!db.findUser(user)) //cannot find user
        {

            // set message indicating login fail
            req.getSession().setAttribute("msg-login-fail", "invalid user or password mismatch!");
            //redirect to login
            resp.sendRedirect("login?");

        } else {
            HttpSession session = req.getSession(); //creates new session if none exists
            session.setAttribute("user", user); //store username in session

            if(rememberMe!=null && rememberMe.equals("on")) //Remember me is checked
            {
                Cookie c = new Cookie("remember-me", name);
                c.setMaxAge(60 * 60 * 24 * 30); // expire in 30 days
                resp.addCookie(c);
            }
            else
            {

                Cookie c = new Cookie("remember-me", "");
                c.setMaxAge(0); // expire immediately
                resp.addCookie(c);
            }

           //search "promo" cookie
           if(req.getCookies()!=null) {
               Optional<String> s = Arrays.stream(req.getCookies())
                       .filter(c -> "promo".equals(c.getName()))
                       .map(Cookie::getValue)
                       .findAny();
               if (!s.isPresent()) { // if not, create one for this user
                   Cookie promotionCookie = new Cookie("promo", "$100");
                   promotionCookie.setMaxAge(60 * 60 * 24 * 30); // expire in 30 days
                   resp.addCookie(promotionCookie);
               }
           }


           resp.sendRedirect("shopping"); // within same application
        }
}}
