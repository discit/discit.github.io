package lab12;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/shopping")
public class Shopping extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //init DB
        Database db = (Database) req.getServletContext().getAttribute("database");
        if(db == null)
        {
            //create one
            db = new Database();
            req.getServletContext().setAttribute("database", db);
        }
        List<Product> products = db.getProducts();
        req.setAttribute("product", products);


        RequestDispatcher dispatcher = req.getRequestDispatcher("shopping.jsp");
        dispatcher.forward(req, resp);

    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        PrintWriter writer = resp.getWriter();
        String name = req.getParameter("username");
        String pass = req.getParameter("password");
        String rememberMe = req.getParameter("remember-me");
        User user = new User(name, pass);

    }
}
