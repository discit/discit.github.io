package lab12;
import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    List<Product> cart = new ArrayList<>();
    public ShoppingCart() {
        ;
    }
    public ShoppingCart(List<Product> cart) {
        this.cart = cart;
    }
    void addProduct(Product product){
        cart.add(product);
    }
}
