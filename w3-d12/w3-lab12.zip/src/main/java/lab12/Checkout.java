package lab12;

import com.google.gson.Gson;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;


@WebServlet("/checkout")
public class Checkout extends HttpServlet {
    Gson mapper = new Gson();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String cart = req.getParameter("cart");
        System.out.println("cart:" + cart);
        //init DB
        Database db = (Database) req.getServletContext().getAttribute("database");
        if(db == null)
        {
            //create one
            db = new Database();
            req.getServletContext().setAttribute("database", db);
        }
        //add purchase for logging if needed
        User user = (User) req.getSession().getAttribute("user");
        if(user!=null) {
            Purchase purchase = new Purchase(user.getUsername(), cart);
            db.addPurchase(purchase);
        }
        ///
        Map[] order = mapper.fromJson(cart, Map[].class);
//        for(int i=0;i<order.length;i++)
//            resp.getWriter().println(order[i].values().toString());

        req.setAttribute("order", order);
        RequestDispatcher view = req.getRequestDispatcher("CheckoutConfirmation.jsp");
        view.forward(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


    }
}
