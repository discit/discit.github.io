window.onload = function () {
    document.querySelectorAll("#product button").forEach(e => e.onclick = updateCart);
    refreshCart();
    document.querySelector("#checkout").addEventListener("click", checkOut);
    document.querySelector("#cart-number").addEventListener("click", cartDetail);
}
function checkOut(){
    let cart = localStorage.getItem("cart");
    if(cart!=null)
    {
        window.open("profile","_self");
    }
    else
        alert("no product to checkout");
}

function cartDetail(){
    let cart = localStorage.getItem("cart");
    let div = document.createElement("div");
    div.className = "cart-detail"
    div.id = "cart-detail";

    if(cart==null)
    {
        div.innerHTML="<p>there is no product in your cart</p>";
    }
    else
    {
        cart = JSON.parse(cart);
        let html = ["<p>product \t quantity</p>"];

        for(let e of cart) {
            div.insertAdjacentHTML("beforeend", "<p>" + e.name + "\t" + e.price + "\t" + e.number+ " </p>");
        }
    }
    let el = document.querySelector("#cart-detail");
    if(el!=null)
        el.replaceWith(div);
    else
        document.querySelector("#cart").append(div);
}
function updateCart() {
    //alert("You clicked on the " + this.id);
  //localStorage.removeItem("cart");
    let cart = localStorage.getItem("cart");
    if(cart==null)
    {
        //create new cart
        // alert(this.dataset.price);
         cart = [{ name: this.id, price: this.dataset.price, number: 1}];
        localStorage.setItem("cart", JSON.stringify(cart));
        refreshCart();
        if(document.querySelector("#cart-detail")!=null)
            cartDetail();
    }
    else
    {
        cart = JSON.parse(cart);
        let i =0;

        for(i=0;i<cart.length; i++)
        {
            if(cart[i].name == this.id)
            {
                cart[i].number = cart[i].number+1;
                break;
            }
        }
        if(i==cart.length)
            cart[i] = { name: this.id, price: this.dataset.price ,number: 1}
        localStorage.setItem("cart", JSON.stringify(cart));


        refreshCart();
        if(document.querySelector("#cart-detail")!=null)
            cartDetail();
    }

}
function refreshCart(){

    let cart = localStorage.getItem("cart");
    if (cart!=null) {
        cart = JSON.parse(cart);
        let sum = 0;
        for (let e of cart)
            sum += e.number;
        document.querySelector("#cart-number").innerHTML = sum.toString();
    }
}
