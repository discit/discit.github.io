window.onload = function () {
    let cart = localStorage.getItem("cart");
    alert(cart);
    document.querySelector("#cart").value = cart;
}
