window.onload = function () {
    //alert("hello");
    localStorage.removeItem("cart");
    document.querySelector("#btn-continue").addEventListener("click", goHome);

}
function goHome()
{
    window.open("shopping","");
}
