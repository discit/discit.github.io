window.onload = function () {
    localStorage.removeItem("cart");
}
