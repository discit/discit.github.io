import java.util.ArrayList;
import java.util.List;

public class Database {
    List<User> users = new ArrayList<>();
    Database(){
        users.add(new User("user1", "123456"));
        users.add(new User("user2", "123456"));
        users.add(new User("user3", "123456"));
    }
    boolean findUser(User user){
        return users.contains(user);
    }
}
