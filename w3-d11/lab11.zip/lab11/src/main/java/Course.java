import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/course")
public class Course extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        PrintWriter writer = resp.getWriter();

        writer.print("<html>");
        writer.write("<title>Courses</title>");
        writer.write("<body>");
        writer.write("<div style=\"width:50%;text-align:center;margin-left:auto;margin-right:auto\">");
        writer.write("<h1>Courses</h1>");
        writer.write("<p style=\"margin-right:20px;text-align:right\"><a href=\"/lab11/logout\">Logout</a></p>");
        writer.write("<p><a href=\"/lab11/coursedetail\"> Course 1</a></p>");
        writer.write("<p><a href=\"/lab11/coursedetail\"> Course 2</a></p>");
        writer.write("</div>");
        writer.write("</body>");
        writer.write("</html>");

    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
}
