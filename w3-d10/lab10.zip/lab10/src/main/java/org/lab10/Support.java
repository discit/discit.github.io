package org.lab10;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/support")
public class Support extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        out.print("<html><head><title>Support</title></head><body>");
        out.print("<form method=\"POST\">");
        out.print("<p>Name: <input type=\"text\" name=\"name\"></p>");
        out.print("<p>Email: <input type=\"text\" name=\"email\"></p>");
        out.print("<p>Problem: <input type=\"text\" name=\"problem\"></p>");
        out.print("<p>Problem description</p>");
        out.print("<p><textarea name=\"desc\" id=\"\" cols=\"100\" rows=\"10\"></textarea></p>");
        out.print("<input type=\"submit\" value=\"help\">");
        out.print("</form>");
        out.print("</body></html>");

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        String input = req.getParameter("name");
        String email = req.getParameter("email");
        int ticket = (int)(Math.random() * 10000);

        ServletContext sc = this.getServletContext();
        String supportEmail = sc.getInitParameter("support-email");


        out.print("<html><head><title>Support</title></head><body>");
        out.print("<p>Thank you!<strong> " + input + "</strong> ");
        out.print("for contacting us. <br> We should receive reply from us with in 24 hrs in");
        out.print("your email address <strong>" + email + "</strong>\n");
        out.print("<br>Let us know in our support email <strong>" + supportEmail + "</strong> if you do not receive reply within 24 hrs. <br> Please be sure to attach your reference");
        out.print("<strong> " + ticket + "</strong> in your email.");
        out.print("</body></html>");

    }
}
